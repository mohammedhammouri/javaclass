package com.example;

public interface IOParser {

    void parse(String input);

    String getOutput();

}
